"""
modelarts service error code definition
"""
from collections import OrderedDict

from model_service import log

logger = log.getLogger(__name__)


class ModelArtsError(Exception):
    """Base class for AIS exceptions"""
    code_key = 'erno'
    msg_key = 'msg'
    code = NotImplemented
    msg = NotImplemented

    def to_dict(self):
        """convert to an OrderedDict that can be used to update json result"""
        return OrderedDict([[self.code_key, self.code],
                            [self.msg_key, self.msg]])

    def __str__(self):
        return 'ModelArtsError: (%s, %s)' % (self.code, self.msg)


class SP0100(ModelArtsError):
    """Specific ModelArts error"""
    code = 'SP.0100'
    msg = 'Succeeded'


class SP0101(ModelArtsError):
    """Specific ModelArts error"""
    code = 'SP.0101'
    msg = 'The input data is invalid'


class SP0105(ModelArtsError):
    """Specific ModelArts error"""
    code = 'SP.0105'
    msg = 'Predict failed'


__all__ = ['ModelArtsError', 'SP0100', 'SP0101', 'SP0105']
