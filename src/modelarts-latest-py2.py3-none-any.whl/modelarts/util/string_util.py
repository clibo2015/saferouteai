"""
Description: This file provides some common functions to process string
Author: ModelArts SDK Team
Date: 2021/11/01 - 2021/12/30
"""
import os

from modelarts.util.config import Config

HTTP_PREFIX = "http://"
HTTPS_PREFIX = "https://"
OPERATORS = ["==", "!=", "~=", ">=", "<=", ">", "<", "="]


class Version:
    _major = None
    _minor = None
    _patch = None
    major = 0
    minor = 0
    patch = 0
    build = ()
    judge = None

    def __eq__(self, other):
        if self._major != other._major or self._minor != other._minor or self._patch != other._patch:
            return False

        return self.major == other.major and self.minor == other.minor and self.patch == other.patch

    def __lt__(self, other):
        if self.major < other.major:
            return True
        elif self.major > other.major:
            return False
        if self.minor < other.minor:
            return True
        elif self.minor > other.minor:
            return False
        if self.patch < other.patch:
            return True
        elif self.patch > other.patch:
            return False
        return False

    def __gt__(self, other):
        if self.major > other.major:
            return True
        elif self.major < other.major:
            return False
        if self.minor > other.minor:
            return True
        elif self.minor < other.minor:
            return False
        if self.patch > other.patch:
            return True
        elif self.patch < other.patch:
            return False
        return False

    def common_cmp(self, other):
        """
        没有指定对比符号时的比较逻辑，遵循semantic_version逻辑
        """
        if self._major is None or other._major is None:
            return False

        if self.major != other.major:
            return False

        if self._minor is None:
            return True
        elif other._minor is None or self.minor != other.minor:
            return False

        if self._patch is None:
            return True
        elif other._patch is None or self.patch != other.patch:
            return False
        return True

    def __ne__(self, other):
        return not self.__eq__(other)

    def __ge__(self, other):
        return self.__eq__(other) or self.__gt__(other)

    def __le__(self, other):
        return self.__eq__(other) or self.__lt__(other)


def get_version(version_str: str) -> Version:
    version = Version()
    if not version_str:
        return version

    split_version = version_str.split('.')
    if len(split_version) == 1:
        version.major = split_version[0]
        version._major = version.major
    elif len(split_version) == 2:
        version.major, version.minor = split_version[0], split_version[1]
        version._major = version.major
        version._minor = version.minor
    elif len(split_version) >= 3:
        version.major, version.minor, version.patch = split_version[0], split_version[1], split_version[2]
        version.build = tuple(split_version[3:])
        version._major = version.major
        version._minor = version.minor
        version._patch = version.patch
    if not split_version[0].isdigit():
        for op in OPERATORS:
            if split_version[0].startswith(op):
                version_str = split_version[0][len(op):].strip()
                version.major = version_str
                version._major = version.major
                version.judge = op
                break
    try:
        version.major = int(version.major)
        version.minor = int(version.minor)
        version.patch = int(version.patch)
    except Exception:
        raise ValueError("Version must be digital.")

    return version


def match_version(spec: Version, version: Version) -> bool:
    if spec.judge is None:
        return spec.common_cmp(version)

    elif spec.judge == "==" or spec.judge == "=":
        return spec == version

    elif spec.judge == "!=":
        return spec != version

    elif spec.judge == ">=" or spec.judge == "~=":
        return spec <= version

    elif spec.judge == "<=":
        return spec >= version

    elif spec.judge == ">":
        return spec < version

    elif spec.judge == "<":
        return spec > version
    return False


def contains_zh(s: str):
    """
    If a string containers chinese.
    :param s: a string to be judged
    :return: True of False
    """
    for c in s:
        if '\u4e00' <= c <= '\u9fa5':
            return True
    return False


def query_var(cfg_var, env_var=None, remove_prefix=False):
    """
    Query variable from config file or environment variables.
    :param cfg_var: query from config.ini
    :param env_var: query from environment variables
    :param remove_prefix: whether to remove protocol prefix
    """

    def _remove_prefix(_var, _remove_prefix=False):
        if not _remove_prefix:
            return _var
        if _var.startswith(HTTP_PREFIX):
            return _var.replace(HTTP_PREFIX, "")
        if _var.startswith(HTTPS_PREFIX):
            return _var.replace(HTTPS_PREFIX, "")
        return _var

    res_cfg = Config.getenv(cfg_var, default=None)
    if res_cfg is not None:
        return _remove_prefix(res_cfg, _remove_prefix=remove_prefix)
    if env_var is None:
        return None
    res_env = os.environ.get(env_var, None)
    return _remove_prefix(res_env, _remove_prefix=remove_prefix) if res_env is not None else None
