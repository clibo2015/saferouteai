"""
Description: Start a process and execute a command
Author: ModelArts SDK Team
Date: 2020/10/01 - 2020/10/30
"""
import subprocess
import sys
import time

from threading import Thread


def ignore_warning(exception):
    return exception


def _log_handler(file):
    for line in iter(file.readline, ""):
        if isinstance(line, bytes):
            try:
                stripped = line.decode().rstrip("\r\n")
                last = stripped.split("\r")[-1]
                sys.stdout.write(last + "\n")
                sys.stdout.flush()
            except Exception as e:
                ignore_warning(e)

        if not line:
            break


def execute_command(*popenargs, **kwargs):
    """
    execute a command
    :param popenargs: parameters of Popen command
    """
    kwargs["stdout"] = kwargs.get("stdout") or subprocess.PIPE
    kwargs["stderr"] = kwargs.get("stderr") or subprocess.PIPE

    try:
        line_buffer = ["stdbuf", "-oL", "-eL"]
        line_buffer.extend(*popenargs)
        process = subprocess.Popen(line_buffer, **kwargs)
        stdout_thread = Thread(target=_log_handler, args=[process.stdout])
        stderr_thread = Thread(target=_log_handler, args=[process.stderr])
        stdout_thread.daemon = stderr_thread.daemon = True
        stdout_thread.start()
        stderr_thread.start()

        while process.returncode is None:
            time.sleep(0.1)
            process.poll()

        stdout_thread.join()
        stderr_thread.join()
    except Exception as e:
        exception_handler = kwargs.get("exception_handler")
        if exception_handler:
            exception_handler(e)
        else:
            raise

    if process.returncode:
        raise subprocess.CalledProcessError(process.returncode, popenargs[0])
    return 0


class ProgressDisplay(object):

    """ This class is used to manage the output information when waiting a process executing.
    """

    PROGRESS_DISPLAY_INTERVAL = 5

    def __init__(self, show_progress=True, msg="", repeated_symbol=".", new_line=True):
        """
        Initialize an instance.
        :param msg: The message you want display first.
        :param repeated_symbol: This symbol will be displayed repeatedly to tell user the process is still in progress.
        :param new_line: This parameter determines if starts a new line after displaying all the progress information.
        """
        self.__msg = msg
        self.__repeated_symbol = repeated_symbol
        self.__new_line = new_line
        self.__show_progress = show_progress

    @property
    def msg(self):
        return self.__msg

    @property
    def repeated_symbol(self):
        return self.__repeated_symbol

    @property
    def new_line(self):
        return self.__new_line

    def wait(self, process):
        """
        Wait the process done.
        :param process: the ongoing process
        """
        if self.__show_progress:
            self._show_progress(process)
        else:
            self._just_wait(process)

    def _show_progress(self, process):
        """
        Display the progress of a process using the format 'mgs....done'.
        :param process: the ongoing process
        """
        print(self.__msg, end="", flush=True)
        while process.poll() is None:
            print(self.__repeated_symbol, end="", flush=True)
            time.sleep(self.PROGRESS_DISPLAY_INTERVAL)
        if self.__new_line:
            print("done", flush=True)

    def _just_wait(self, process):
        """
        Wait the process done and output nothing.
        :param process: the ongoing process
        """
        while process.poll() is None:
            time.sleep(self.PROGRESS_DISPLAY_INTERVAL)
