"""
Description: Cloud notebook management
Author: ModelArts SDK Team
Date: 2020/05/14 - 2021/06/30
"""
import logging
import time
from json import JSONEncoder

from . import constant
from .config.auth import auth_by_apig
from .session import Session
from .util import notebook_util
from .util.secret_util import auth_expired_handler
from .notebooks.notebook_api import get_notebook_api_instance
from .images.image_api import get_image_api_instance

logging.getLogger().setLevel(logging.INFO)
ATTACHED_NOTEBOOK_QUERY_INTERVAL = 5
ATTACHED_NOTEBOOK_MAX_WAIT_TIMES = 24

ATTACHED_NOTEBOOK_STATUS = "status"
ATTACHED_NOTEBOOK_SUB_STATUS = "sub_status"
ATTACHED_NOTEBOOK_PENDING = "PENDING"
ATTACHED_NOTEBOOK_CREATING = "CREATING"
ATTACHED_NOTEBOOK_RUNNING = "RUNNING"
ATTACHED_NOTEBOOK_SUCCEEDED = "SUCCEEDED"
ATTACHED_NOTEBOOK_FAILED = "FAILED"
ATTACHED_NOTEBOOK_STOPPED = "STOPPED"
ATTACHED_NOTEBOOK_DELETED = "DELETED"
ATTACHED_NOTEBOOK_TIMEOUT = "TIMEOUT"
ATTACHED_NOTEBOOK_CREATE_FAILED = "CREATE_FAILED"
LOCAL_DISTRIBUTED_TRAINING_NUM = 2


class Notebook(object):
    """
    This class is used to create, query and delete an attached notebook.
    """

    def __init__(self, session):
        """
        :param session: modelarts session
        """
        # sdk interacts directly with authoring-service without going through roma
        self.session = Session() if session.auth == constant.ROMA_AUTH else session

    @auth_expired_handler
    def create_attached_notebook(self, body):
        """
        Create an attached notebook to simulate distributed training
        :param body: request body when creating attached notebook.
        :return result of creating attached notebook. For example
        {
          "auth_token": "string",
          "create_time": "2021-08-05T02:26:55.670Z",
          "endpoint": "string",
          "flavor": "string",
          "id": "string",
          "status": "BINDING",
          "sub_status": "FAILED",
          "type": "DISTRIBUTED_TRAIN",
          "update_time": "2021-08-05T02:26:55.670Z"
        }
        """
        request = "/v1/{project_id}/notebooks/{notebook_id}/app". \
            format(project_id=self.session.project_id, notebook_id=notebook_util.get_notebook_id())
        body_encode = JSONEncoder().encode(body)
        logging.info("Start creating distributed training worker.")
        return auth_by_apig(self.session, constant.HTTPS_POST, request, body=body_encode)

    @staticmethod
    def get_attached_notebook_status(response_list):
        """
        Get attached notebook status. For each notebook or devcontainer, there is only one attached notebook at most.
        The abnormal states should be acquired from 'status' in response_list including 'DELETED', 'CREATE_FAILED'
        and 'STOPPED'. The normal states should be acquired from 'sub_status' in response_list including 'PENDING',
        'RUNNING', 'FAILED' and 'SUCCEEDED'.
        :param response_list: response of query request
        :return: status
        """
        data = response_list["data"]
        if len(data) == 0:
            return ATTACHED_NOTEBOOK_DELETED
        else:
            response = data[0]
            status = response[ATTACHED_NOTEBOOK_STATUS].upper()
            # Only STOPPED and CREATE_FAILED are abnormal status
            return status if status == ATTACHED_NOTEBOOK_CREATE_FAILED \
                else response[ATTACHED_NOTEBOOK_SUB_STATUS].upper()

    def wait_attached_notebook_run(self):
        """
        Waiting the attached notebook to be running.
        """
        running_state_times = 1
        while True:
            response_list = self.list_attached_notebook()
            status = self.get_attached_notebook_status(response_list)
            if status in (ATTACHED_NOTEBOOK_PENDING, ATTACHED_NOTEBOOK_CREATING):
                logging.info("Wait until another distributed training worker running...")
            elif status == ATTACHED_NOTEBOOK_RUNNING:
                if running_state_times == 1:
                    logging.info("Another training worker started successfully and it can run 15min at most.")
                running_state_times += 1
                # For local d910 distributed training, the number of server must be 2
                if not notebook_util.is_ascend910() or notebook_util.get_ascend910_distribute_server_num() == \
                        LOCAL_DISTRIBUTED_TRAINING_NUM:
                    return True
            elif status == ATTACHED_NOTEBOOK_FAILED:
                logging.info("Another distributed training worker failed.")
                return False
            elif status == ATTACHED_NOTEBOOK_SUCCEEDED:
                logging.info("Another distributed training worker succeeded.")
                return False
            elif status == ATTACHED_NOTEBOOK_DELETED:
                error_info = "Internal error. Another distributed training worker was deleted unexpectedly."
                raise Exception(error_info + " Please try again.")
            elif status == ATTACHED_NOTEBOOK_CREATE_FAILED:
                error_info = "TIMEOUT. It takes too long to create another distributed training worker."
                raise Exception(error_info + " Please try again.")
            time.sleep(ATTACHED_NOTEBOOK_QUERY_INTERVAL)

    def wait_attached_notebook_finish(self):
        """
        Waiting the attached notebook to run finish.
        """
        while True:
            response_list = self.list_attached_notebook()
            status = self.get_attached_notebook_status(response_list)
            if status == ATTACHED_NOTEBOOK_RUNNING:
                logging.info("Another distributed training worker is still running.")
            elif status == ATTACHED_NOTEBOOK_SUCCEEDED:
                logging.info("Training Job in another distributed training worker succeeded.")
                break
            elif status == ATTACHED_NOTEBOOK_FAILED:
                logging.info("Training Job in another distributed training worker failed.")
                break
            elif status == ATTACHED_NOTEBOOK_DELETED:
                error_info = "Internal error. Another distributed training worker was deleted unexpectedly."
                raise Exception(error_info + " Please try again.")
            elif status == ATTACHED_NOTEBOOK_TIMEOUT:
                logging.warning("Training Job in another distributed training worker was terminated because it has "
                                "been running for more than 15 minutes.")
                break
            time.sleep(ATTACHED_NOTEBOOK_QUERY_INTERVAL)

    @auth_expired_handler
    def delete_attached_notebook(self, attached_notebook_id):
        """
        Delete attached notebook in distributed training.
        """
        request = "/v1/{project_id}/notebooks/{notebook_id}/app/{id}".\
            format(project_id=self.session.project_id,
                   notebook_id=notebook_util.get_notebook_id(),
                   id=attached_notebook_id)
        auth_by_apig(self.session, constant.HTTPS_DELETE, request)

    @auth_expired_handler
    def list_attached_notebook(self):
        """
        List attached notebook.
        :return a list of attached notebooks, for example
        {
          "current": 1,
          "data": [
            {
              "auth_token": "string",
              "create_time": "2021-08-05T02:24:12.528Z",
              "endpoint": "string",
              "flavor": "string",
              "id": "string",
              "status": "BINDING",
              "sub_status": "RUNNING",
              "type": "DISTRIBUTED_TRAIN",
              "update_time": "2021-08-05T02:24:12.528Z"
            }
          ],
          "pages": 1,
          "size": 10,
          "total": 10
        }
        """
        request = "/v1/{}/notebooks/{}/app".format(self.session.project_id, notebook_util.get_notebook_id())
        query = {"type": "DISTRIBUTED_TRAIN"}
        return auth_by_apig(self.session, constant.HTTPS_GET, request, query=query)

    @auth_expired_handler
    def get_notebook_info(self, session=None):
        """
        Get the info of current notebook
        :param session: modelarts session
        :return notebook instance info, for example
        {
          ....
          "image": {
            "arch": "AARCH64",
            "current_tag": "string",
            "default_tag": "string",
            "description": "string",
            "dev_service_name": [
              "AI_FLOW"
            ],
            "dev_services": [
              {
                "dev_service_name": "AI_FLOW",
                "path_suffix": "string",
                "protocol": "HTTP",
                "target_port": 0
              }
            ],
            "feature": "DEFAULT",
            "id": "string",
            "is_need_pulled": true,
            "name": "string",
            "namespace": "string",
            "priority": 0,
            "project_id": "string",
            "size": 0,
            "status": "ACTIVE",
            "status_message": "string",
            "support_res_categories": [
              "ASCEND"
            ],
            "swr_full_path": "string",
            "swr_path": "string",
            "token_encrypt": true,
            "type": "BUILD_IN",
            "user_id": "string"
          },
          ....
        """
        session = self.session if session is None else session
        request = "/v1/{}/notebooks/{}".format(session.project_id, notebook_util.get_notebook_id())
        return auth_by_apig(session, constant.HTTPS_GET, request)

    @auth_expired_handler
    def list_notebook_images(self, query=None):
        request = "/v1/{}/images".format(self.session.project_id)
        return auth_by_apig(self.session, constant.HTTPS_GET, request, query=query).get('data', [])

    @auth_expired_handler
    def get_image_info_by_id(self, image_id):
        from modelarts.exception.apig_exception import APIGException

        request = "/v1/{}/images/{}".format(self.session.project_id, image_id)
        response = None
        try:
            response = auth_by_apig(self.session, constant.HTTPS_GET, request)
        except APIGException:
            pass
        return response

    @auth_expired_handler
    def stop_notebook_by_id(self, nb_id):
        request = f"/v1/{self.session.project_id}/notebooks/{nb_id}/stop"
        return auth_by_apig(self.session, constant.HTTPS_POST, request)

    def stop_current_notebook(self):
        nb_id = self.get_notebook_info().get("id")
        return self.stop_notebook_by_id(nb_id)


class NotebookManagement(object):

    @classmethod
    def create(cls, session, notebook):
        if not notebook.image_id:
            limit = 200
            offset = 0
            image_api_instance = get_image_api_instance(session)
            params = dict()
            if notebook.workspace_id:
                params.update({"workspace_id": notebook.workspace_id})
            while True:
                params.update({"offset": offset, "limit": limit})
                image_list = image_api_instance.get_image(query_param=params)
                for cur_image in image_list["data"]:
                    if cur_image["swr_path"] == notebook.image_url:
                        notebook.image_id = cur_image["id"]
                        break
                if notebook.image_id:
                    break
                if image_list["current"] >= image_list["pages"] - 1:
                    break
                offset = limit * (image_list["current"] + 1)
            if not notebook.image_id:
                raise ValueError(f"Cannot find image with image_url {notebook.image_url}")
        api_instance = get_notebook_api_instance(session)
        return cls._convert_status(api_instance.create(notebook))

    @classmethod
    def update(cls, session, notebook_id, dew_secret_name=None):
        api_instance = get_notebook_api_instance(session)
        return cls._convert_status(api_instance.update(notebook_id, dew_secret_name))

    @classmethod
    def delete(cls, session, notebook_id):
        api_instance = get_notebook_api_instance(session)
        return cls._convert_status(api_instance.delete(notebook_id))

    @classmethod
    def get(cls, session, notebook_id):
        api_instance = get_notebook_api_instance(session)
        return cls._convert_status(api_instance.get(notebook_id))

    @classmethod
    def list(cls, session, feature=None, limit=None, name=None, pool_id=None, offset=None, owner=None,
             sort_dir=None, sort_key=None, status=None, workspace_id=None):
        api_instance = get_notebook_api_instance(session)
        param = {}
        if feature:
            param.update({"feature": feature})
        if limit:
            param.update({"limit": limit})
        if name:
            param.update({"name": name})
        if pool_id:
            param.update({"pool_id": pool_id})
        if offset:
            param.update({"offset": offset})
        if owner:
            param.update({"owner": owner})
        if sort_dir:
            param.update({"sort_dir": sort_dir})
        if sort_key:
            param.update({"sort_key": sort_key})
        if status:
            param.update({"status": status})
        if workspace_id:
            param.update({"workspaceId": workspace_id})
        notebook_list = api_instance.list(param)
        for notebook in notebook_list["data"]:
            cls._convert_status(notebook)
        return notebook_list

    @classmethod
    def start(cls, session, notebook_id, duration=None, lease_type=None):
        api_instance = get_notebook_api_instance(session)
        return cls._convert_status(api_instance.start(notebook_id, duration=duration, lease_type=lease_type))

    @classmethod
    def stop(cls, session, notebook_id):
        api_instance = get_notebook_api_instance(session)
        return cls._convert_status(api_instance.stop(notebook_id))

    @classmethod
    def list_flavors(cls, session, category=None):
        api_instance = get_notebook_api_instance(session)
        params = dict()
        if category:
            params.update({"category": category})
        return api_instance.list_flavors(category)

    @classmethod
    def get_cluster_info(cls, session, pool_id):
        api_instance = get_notebook_api_instance(session)
        return api_instance.get_cluster_info(pool_id)

    @classmethod
    def _convert_status(cls, resp):
        # Capitalize the first letter of the state to be consistent with training
        resp["status"] = resp["status"].capitalize()
        return resp
