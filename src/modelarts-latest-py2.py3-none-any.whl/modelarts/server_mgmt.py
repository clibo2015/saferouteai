import logging
import time
import re
from json import JSONEncoder
from typing import Union, Dict, List

from modelarts import constant
from modelarts.config.auth import auth_by_apig
from modelarts.servers.server_def import Volume, BindIP, ImageBody, Server, Tag
from modelarts.session import Session
from modelarts.util.secret_util import auth_expired_handler
from modelarts.servers.server_api import get_server_api_instance
from modelarts.images.image_api import get_image_api_instance

logging.getLogger().setLevel(logging.INFO)
ATTACHED_SERVER_QUERY_INTERVAL = 5
ATTACHED_SERVER_MAX_WAIT_TIMES = 24
ATTACHED_SERVER_STATUS = "status"
ATTACHED_SERVER_SUB_STATUS = "sub_status"
ATTACHED_SERVER_PENDING = "PENDING"
ATTACHED_SERVER_CREATING = "CREATING"
ATTACHED_SERVER_RUNNING = "RUNNING"
ATTACHED_SERVER_SUCCEEDED = "SUCCEEDED"
ATTACHED_SERVER_FAILED = "FAILED"
ATTACHED_SERVER_STOPPED = "STOPPED"
ATTACHED_SERVER_DELETED = "DELETED"
ATTACHED_SERVER_TIMEOUT = "TIMEOUT"
ATTACHED_SERVER_CREATE_FAILED = "CREATE_FAILED"
UNKNOWN = "UNKNOWN"


def validate_server_id(server_id: str) -> None:
    """Validate the server ID format and constraints."""
    if not isinstance(server_id, str):
        raise TypeError("Server ID must be a string.")
    if not server_id:
        raise ValueError("Server ID cannot be empty.")
    if len(server_id) > 64:
        raise ValueError("Server ID must be 64 characters or less.")
    if not re.match(r'^[a-zA-Z0-9_\-]+$', server_id):
        raise ValueError("Server ID can only contain letters, numbers, underscores, and hyphens.")

class ServerManagement(object):
    @classmethod
    def get_user_servers_list(cls, session: Session, owner: str = None, sort_dir: str = None, sort_key: str = None,
                              limit: int = None, offset: int = None):
        api_instance = get_server_api_instance(session)
        param = {}
        if owner:
            param.update({"owner": owner})
        if sort_dir:
            param.update({"sort_dir": sort_dir})
        if sort_key:
            param.update({"sort_key": sort_key})
        if limit:
            param.update({"limit": limit})
        if offset:
            param.update({"offset": offset})
        user_servers_list = api_instance.get_user_servers_list(param)
        for server in user_servers_list.get("data", []):
            cls._convert_status(server)
        return user_servers_list

    @classmethod
    def create(cls, session: Session, server: Server):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.create_server(server))

    @classmethod
    def delete(cls, session: Session, server_id: str):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.delete_server(server_id))

    @classmethod
    def sync_server_status(cls, session: Session, server_id: str = None, owner: str = None, sort_dir: str = None, sort_key: str = None,
                           offset: int = None, limit: int = None):
        api_instance = get_server_api_instance(session)
        if not server_id:
            raise ValueError("server_id is required")
        validate_server_id(server_id)
        param = {}
        if server_id:
            param["id"] = server_id
        if owner:
            param["owner"] = owner
        if sort_dir:
            param["sort_dir"] = sort_dir
        if sort_key:
            param["sort_key"] = sort_key
        if offset is not None:
            param["offset"] = offset
        if limit:
            param["limit"] = limit
        try:
            server_status = api_instance.sync_server_status(params=param)
            data = server_status.get("data", [])
            if not isinstance(data, list):
                logging.warning("Unexpected data format in server_status: 'data' should be a list")
                return server_status
            for status in data:
                cls._convert_status(status)
        except Exception as e:
            logging.error("Failed to sync server status: %s", str(e))
            return {"status": "error", "message": str(e)}
        return server_status

    @classmethod
    def start(cls, session: Session, server_id: str):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.start_server(server_id))

    @classmethod
    def stop(cls, session: Session, server_id: str):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.stop_server(server_id))

    @classmethod
    def get_server_info(cls, session: Session, server_id: str):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.get_server_info(server_id))

    @classmethod
    def create_hps_tag(cls, session: Session, hps_cluster_id: str, tags: List[Tag]):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.create_hps_tag(hps_cluster_id, tags))

    @classmethod
    def delete_hps_tag(cls, session: Session, hps_cluster_id: str, tags: List[Tag]):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.delete_hps_tag(hps_cluster_id, tags))

    @classmethod
    def get_hps_tags(cls, session: Session, hps_cluster_id: str):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.get_hps_tags(hps_cluster_id))

    @classmethod
    def reinstall_server_image(cls, session: Session, server_id: str, image_body:ImageBody):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.reinstall_server_image(server_id, image_body))

    @classmethod
    def change_server_image(cls, session: Session, server_id: str, image_body: ImageBody):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.change_server_image(server_id, image_body))

    @classmethod
    def change_hps_image(cls, session: Session, hps_cluster_id: str, image_body: ImageBody):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.change_hps_image(hps_cluster_id, image_body))

    @classmethod
    def get_hps_list(cls, session: Session, sort_dir: str = None, sort_key: str = None, limit: int = None,
                     offset: int = None):
        api_instance = get_server_api_instance(session)
        param = {}
        if sort_dir:
            param["sort_dir"] = sort_dir
        if sort_key:
            param["sort_key"] = sort_key
        if limit is not None:
            param["limit"] = limit
        if offset is not None:
            param["offset"] = offset
        try:
            user_hps_list = api_instance.get_hps_list(param)
            data = user_hps_list.get("data", [])
            if not isinstance(data, list):
                logging.warning("Unexpected data format in user_hps_list: 'data' should be a list")
                user_hps_list["data"] = []
                return user_hps_list
            for hps in data:
                cls._convert_status(hps)
        except Exception as e:
            logging.error("Failed to get hps list: %s", str(e))
            return {"status": "error", "message": str(e)}
        return user_hps_list

    @classmethod
    def get_hps_info(cls, session: Session, hps_cluster_id: str):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.get_hps_info(hps_cluster_id))

    @classmethod
    def delete_hps(cls, session: Session, hps_cluster_id: str):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.delete_hps(hps_cluster_id))

    @classmethod
    def restart(cls, session: Session, server_id: str):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.restart(server_id))

    @classmethod
    def start_hps(cls, session: Session, hps_cluster_id: str):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.start_hps(hps_cluster_id))

    @classmethod
    def stop_hps(cls, session: Session, hps_cluster_id: str):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.stop_hps(hps_cluster_id))

    @classmethod
    def attach_volume(cls, session: Session, server_id: str, volume: Volume):
        api_instance = get_server_api_instance(session)
        return cls._convert_status(api_instance.attach_volume(server_id, volume))

    @classmethod
    def _convert_status(cls, resp):
        if resp is None:
            # 如果响应为 None，则不返回状态信息
            return None
        # 仅当响应中存在 status 字段时才处理
        status = resp.get("status")
        if isinstance(status, str) and status:
            # 将状态首字母大写，以统一格式
            resp["status"] = status.capitalize()
        else:
            resp["status"] = UNKNOWN
        return resp