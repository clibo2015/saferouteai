from abc import ABCMeta, abstractmethod
from json import JSONEncoder

from modelarts import constant
from modelarts.config.auth import auth_by_apig
from modelarts.util.secret_util import auth_expired_handler
from six import with_metaclass


class APIInterfaceBase(with_metaclass(ABCMeta, object)):
    """

    """

    def __init__(self):
        """
        Initialize a APIInterface instance.
        """

    @abstractmethod
    def create_workflow(self, body):
        """create structured workflow
        """
        pass

    @abstractmethod
    def update_workflow(self, workflow_id, body):
        """update structured workflow
        """
        pass

    @abstractmethod
    def get_workflow(self, workflow_id):
        """get workflow info
        """
        pass

    @abstractmethod
    def delete_workflow(self, workflow_id):
        """delete workflow instance
        """
        pass

    @abstractmethod
    def list_workflows(self, **kwargs):
        """list workflows
        """
        pass

    @abstractmethod
    def create_execution(self, workflow_id, body):
        """create execution
        """
        pass

    @abstractmethod
    def get_execution(self, workflow_id, execution_id):
        """get execution info
        """
        pass

    @abstractmethod
    def update_execution(self, workflow_id, execution_id, body):
        """update execution info
        """
        pass

    @abstractmethod
    def delete_execution(self, workflow_id, execution_id):
        """delete execution instance
        """
        pass

    @abstractmethod
    def list_executions(self, workflow_id):
        """list executions for specified workflow
        """
        pass

    @abstractmethod
    def operate_execution(self, workflow_id, execution_id, body):
        """operate execution, support stop、rerun
        """
        pass

    @abstractmethod
    def operate_step_execution(self, workflow_id, execution_id, step_execution_id, body):
        """operate step execution, support retry、stop、continue
        """
        pass

    @abstractmethod
    def create_schedule(self, workflow_id, body):
        """create schedule for specified workflow
        """
        pass

    @abstractmethod
    def get_schedule(self, workflow_id, schedule_id):
        """get schedule info
        """
        pass

    @abstractmethod
    def update_schedule(self, workflow_id, schedule_id):
        """update schedule info
        """
        pass

    @abstractmethod
    def delete_schedule(self, workflow_id, schedule_id):
        """delete schedule instance
        """
        pass


class APIInterfaceAKSKImpl(APIInterfaceBase):
    """

    """

    def __init__(self, session, headers=None):
        """
        Initialize a APIInterface instance when using AKSK auth.
        """
        APIInterfaceBase.__init__(self)
        self.session = session
        self.headers = headers
        self.base_request_url = '/v2/' + self.session.project_id + '/workflows'

    @auth_expired_handler
    def create_workflow(self, body):
        """
        create_workflow
        Args:
            body (dict): create workflow request body

        Returns: create workflow response, including workflow id
        """
        request_url = self.base_request_url
        encode_body = JSONEncoder().encode(body)
        return auth_by_apig(self.session,
                            constant.HTTPS_POST,
                            request_url, body=encode_body,
                            headers=self.headers)

    @auth_expired_handler
    def update_workflow(self, workflow_id, body):
        """
        update_workflow
        Args:
            workflow_id (str): workflow_id
            body (dict):  update workflow request body

        Returns: update workflow response, including workflow id
        """
        request_url = self.base_request_url + '/' + workflow_id
        encode_body = JSONEncoder().encode(body)
        return auth_by_apig(self.session,
                            constant.HTTPS_PUT, request_url, '',
                            body=encode_body,
                            headers=self.headers)

    @auth_expired_handler
    def get_workflow(self, workflow_id):
        """
        get_workflow
        Args:
            workflow_id (str): workflow_id

        Returns: workflow information
        """
        request_url = self.base_request_url + '/' + workflow_id
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url,
                            headers=self.headers)

    @auth_expired_handler
    def delete_workflow(self, workflow_id):
        """
        delete_workflow
        Args:
            workflow_id (str): workflow_id

        Returns:
        """
        request_url = self.base_request_url + '/' + workflow_id
        return auth_by_apig(self.session,
                            constant.HTTPS_DELETE, request_url,
                            headers=self.headers)

    @auth_expired_handler
    def list_workflows(self, **kwargs):
        """
        list workflows according conditions
        Args:
            **kwargs: query args

        Returns: workflow list info

        """
        request_url = self.base_request_url
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url,
                            query=kwargs, headers=self.headers)

    @auth_expired_handler
    def create_execution(self, workflow_id, body=None):
        """
        create_execution
        Args:
            workflow_id (str): workflow_id
            body (dict): create execution request body

        Returns: create execution response, including execution id

        """
        request_url = self.base_request_url + '/' + workflow_id + '/' + 'executions'
        encode_body = JSONEncoder().encode(body)
        return auth_by_apig(self.session,
                            constant.HTTPS_POST,
                            request_url, body=encode_body,
                            headers=self.headers)

    @auth_expired_handler
    def get_execution(self, workflow_id, execution_id):
        """
        get_execution
        Args:
            workflow_id (str): workflow_id
            execution_id (str): execution_id

        Returns: execution information

        """
        request_url = self.base_request_url + '/' + workflow_id + '/' + 'executions' + '/' + execution_id
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url,
                            headers=self.headers)

    @auth_expired_handler
    def update_execution(self, workflow_id, execution_id, body):
        """
        update_execution
        Args:
            workflow_id (str): workflow_id
            execution_id (str): execution_id
            body (dict): update execution request body

        Returns: execution information

        """
        request_url = self.base_request_url + '/' + workflow_id + '/' + 'executions' + '/' + execution_id
        encode_body = JSONEncoder().encode(body)
        return auth_by_apig(self.session,
                            constant.HTTPS_PUT, request_url, body=encode_body,
                            headers=self.headers)

    @auth_expired_handler
    def delete_execution(self, workflow_id, execution_id):
        """
        delete_execution
        Args:
            workflow_id (str): workflow_id
            execution_id (str): execution_id

        Returns:

        """
        request_url = self.base_request_url + '/' + workflow_id + '/' + 'executions' + '/' + execution_id
        return auth_by_apig(self.session,
                            constant.HTTPS_DELETE, request_url,
                            headers=self.headers)

    @auth_expired_handler
    def operate_execution(self, workflow_id, execution_id, body):
        """
        operate_execution
        Args:
            workflow_id (str): workflow_id
            execution_id (str): execution_id
            body (dict): operate execution request body

        Returns: execution information

        """
        request_url = self.base_request_url + '/' + workflow_id + '/' + 'executions' + '/' + execution_id + '/actions'
        encode_body = JSONEncoder().encode(body)
        return auth_by_apig(self.session,
                            constant.HTTPS_POST, request_url, body=encode_body,
                            headers=self.headers)

    @auth_expired_handler
    def list_executions(self, workflow_id, **kwargs):
        """
        delete_execution
        Args:
            workflow_id (str): workflow_id
            **kwargs: query args

        Returns:

        """
        request_url = self.base_request_url + '/' + workflow_id + '/executions'
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url, query=kwargs,
                            headers=self.headers)

    @auth_expired_handler
    def operate_step_execution(self, workflow_id, execution_id, step_execution_id, body):
        """
        operate_execution
        Args:
            workflow_id (str): workflow_id
            execution_id (str): execution_id
            step_execution_id (str): step_execution_id
            body (dict): operate step execution request body

        Returns: execution information

        """
        request_url = self.base_request_url + '/' + workflow_id + '/executions/' + execution_id + \
                      '/step-executions/' + step_execution_id + '/actions'
        encode_body = JSONEncoder().encode(body)
        return auth_by_apig(self.session,
                            constant.HTTPS_POST, request_url, body=encode_body,
                            headers=self.headers)

    @auth_expired_handler
    def create_schedule(self, workflow_id, body):
        """
        create_execution
        Args:
            workflow_id (str): workflow_id
            body (dict): create schedule request body

        Returns: schedule info

        """
        request_url = self.base_request_url + '/' + workflow_id + '/schedules'
        encode_body = JSONEncoder().encode(body)
        return auth_by_apig(self.session,
                            constant.HTTPS_POST,
                            request_url, body=encode_body,
                            headers=self.headers)

    @auth_expired_handler
    def get_schedule(self, workflow_id, schedule_id):
        """
        get_schedule
        Args:
            workflow_id (str): workflow_id
            schedule_id (str): schedule id

        Returns: schedule info

        """
        request_url = self.base_request_url + '/' + workflow_id + '/schedules/' + schedule_id
        return auth_by_apig(self.session,
                            constant.HTTPS_GET,
                            request_url, headers=self.headers)

    @auth_expired_handler
    def delete_schedule(self, workflow_id, schedule_id):
        """
        delete_schedule
        Args:
            workflow_id (str): workflow_id
            schedule_id (str): schedule id

        Returns:

        """
        request_url = self.base_request_url + '/' + workflow_id + '/schedules/' + schedule_id
        return auth_by_apig(self.session,
                            constant.HTTPS_DELETE,
                            request_url, headers=self.headers)

    @auth_expired_handler
    def update_schedule(self, workflow_id, schedule_id, body):
        """
        update_schedule
        Args:
            workflow_id (str): workflow_id
            schedule_id (str): schedule id
            body (dict): update schedule request body

        Returns: schedule info

        """
        request_url = self.base_request_url + '/' + workflow_id + '/schedules/' + schedule_id
        encode_body = JSONEncoder().encode(body)
        return auth_by_apig(self.session,
                            constant.HTTPS_PUT, request_url,
                            body=encode_body, headers=self.headers)
