from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from modelarts.workflow.resource.workspace import Workspace  # noqa: F401
