import logging
from abc import ABCMeta, abstractmethod
from json import JSONEncoder
from typing import List
import re

from modelarts import constant
from modelarts.config.auth import auth_by_apig
from modelarts.exception.apig_exception import APIGException
from modelarts.servers.server_def import Volume, BindIP, ImageBody, Server, Tag


logging.getLogger().setLevel(logging.INFO)


def validate_server_id(server_id: str) -> None:
    """Validate the server ID format and constraints."""
    if not isinstance(server_id, str):
        raise TypeError("Server ID must be a string.")
    if not server_id:
        raise ValueError("Server ID cannot be empty.")
    if len(server_id) > 64:
        raise ValueError("Server ID must be 64 characters or less.")
    if not re.match(r'^[a-zA-Z0-9_\-]+$', server_id):
        raise ValueError("Server ID can only contain letters, numbers, underscores, and hyphens.")


class ServerApi(metaclass=ABCMeta):
    """These Apis can interact with modelarts management service."""
    @abstractmethod
    def get_user_servers_list(self, params=None):
        """get the list of user's servers
        :param params: parameters like 'owner' or 'sort_dir'
        """
        pass

    @abstractmethod
    def create_server(self, server: Server):
        pass

    @abstractmethod
    def delete_server(self, server_id: str):
        pass

    @abstractmethod
    def sync_server_status(self, params=None):
        pass

    @abstractmethod
    def start_server(self, server_id: str):
        pass

    @abstractmethod
    def stop_server(self, server_id: str):
        pass

    @abstractmethod
    def get_server_info(self, server_id: str):
        pass

    @abstractmethod
    def create_hps_tag(self, hps_cluster_id: str, tags: List[Tag]):
        pass

    @abstractmethod
    def delete_hps_tag(self, hps_cluster_id: str, tags: List[Tag]):
        pass

    @abstractmethod
    def get_hps_tags(self, hps_cluster_id: str):
        pass

    @abstractmethod
    def reinstall_server_image(self, server_id: str, image_body: ImageBody):
        pass

    @abstractmethod
    def change_server_image(self, server_id: str, image_body: ImageBody):
        pass

    @abstractmethod
    def change_hps_image(self, hps_cluster_id: str, image_body: ImageBody):
        pass

    @abstractmethod
    def get_hps_list(self, params=None):
        pass

    @abstractmethod
    def get_hps_info(self, hps_cluster_id: str):
        pass

    @abstractmethod
    def delete_hps(self, hps_cluster_id: str):
        pass

    @abstractmethod
    def restart(self, server_id: str):
        pass

    @abstractmethod
    def start_hps(self, hps_cluster_id: str):
        pass

    @abstractmethod
    def stop_hps(self, hps_cluster_id: str):
        pass

    @abstractmethod
    def attach_volume(self, server_id: str, volume: Volume):
        pass

    @abstractmethod
    def bind_eip(self, server_id: str, bind_ip: BindIP):
        pass

    @abstractmethod
    def get_server_eip(self, server_id: str):
        pass


class ServerApiAKSKImpl(ServerApi):
    def __init__(self, session):
        super().__init__()
        self._session = session

    # 查询用户所有DevServer实例列表
    def get_user_servers_list(self, params=None):
        if not params:
            params = dict()
        request_url = "/v1/" + self._session.project_id + "/dev-servers"
        return auth_by_apig(self._session, constant.HTTPS_GET, request_url, query=params)

    # 创建DevServer实例
    def create_server(self, server: Server):
        body = {"flavor": server.flavor,
                "image_id": server.image_id,
                "name": server.name,
                "network": {
                    "security_group_id": server.network.security_group_id,
                    "subnet_id": server.network.subnet_id,
                    "vpc_id": server.network.vpc_id
                }}
        if server.network.roce_id:
            body["network"].update({"roce_id": server.network.roce_id})
        if server.network.ipv6_enable:
            body["network"].update({"ipv6_enable": server.network.ipv6_enable})
        if server.arch:
            body.update({"arch": server.arch})
        if server.admin_pass:
            body.update({'admin_pass': server.admin_pass})
        if server.availability_zone:
            body.update({"availability_zone": server.availability_zone})
        if server.charging_info:
            body["charging_info"] = {"charging_mode": server.charging_info.charging_mode,
                                     "period_num": server.charging_info.period_num,
                                     "period_type": server.charging_info.period_type,
                                     "is_auto_pay": server.charging_info.is_auto_pay,
                                     "is_auto_renew": server.charging_info.is_auto_renew}
        if server.key_pair_name:
            body.update({"key_pair_name": server.key_pair_name})
        if server.root_volume:
            body["root_volume"] = {"type": server.root_volume.root_type,
                                    "size": server.root_volume.size}
        if server.data_volume:
            body["data_volume"] = {"type": server.data_volume.data_type,
                                    "size": server.data_volume.size,
                                    "count": server.data_volume.count}
        if server.server_type:
            body.update({"server_type": server.server_type})
        if server.userdata:
            body.update({"userdata": server.userdata})
        if server.hps_cluster_id:
            body.update({"hps_cluster_id": server.hps_cluster_id})
        if server.enterprise_project_id:
            body.update({"enterprise_project_id": server.enterprise_project_id})
        if server.count:
            body.update({"count": server.count})
        request_url = "/v1/" + self._session.project_id + "/dev-servers"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_POST, request_url, body=JSONEncoder().encode(body))
        except APIGException as e:
            logging.error("Failed to create devserver. %s", str(e))
            return None
        logging.info("Successfully create devservers %s.", server.name)
        return resp

    # 删除DevServer实例
    def delete_server(self, server_id: str):
        validate_server_id(server_id)
        request_url = "/v1/" + self._session.project_id + "/dev-servers/" + server_id
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_DELETE, request_url)
        except APIGException as e:
            logging.error("Failed to delete devserver %s. %s", server_id, str(e))
            return None
        logging.info("Successfully deleted devserver %s.", server_id)
        return resp

    # 实时同步用户所有DevServer实例状态
    def sync_server_status(self, params=None):
        if not params or "id" not in params:
            raise ValueError("Missing required parameter 'server_id'")
        request_url = f"/v1/{self._session.project_id}/dev-servers/sync"
        return auth_by_apig(self._session, constant.HTTPS_PUT, request_url, query=params)

    # 启动DevServer实例
    def start_server(self, server_id: str):
        validate_server_id(server_id)
        request_url = f"/v1/{self._session.project_id}/dev-servers/{server_id}/start"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_PUT, request_url)
        except APIGException as e:
            logging.error("Failed to start devserver %s: %s", server_id, str(e))
            return None
        logging.info("Successfully started devserver %s", server_id)
        return resp

    # 停止DevServer实例
    def stop_server(self, server_id: str):
        validate_server_id(server_id)
        request_url = f"/v1/{self._session.project_id}/dev-servers/{server_id}/stop"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_PUT, request_url)
        except APIGException as e:
            logging.error("Failed to stop devserver %s: %s", server_id, str(e))
            return None
        logging.info("Successfully stopped devserver %s", server_id)
        return resp

    #查询DevServer实例详情
    def get_server_info(self, server_id: str):
        validate_server_id(server_id)
        request_url = f"/v1/{self._session.project_id}/dev-servers/{server_id}"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_GET, request_url)
        except APIGException as e:
            logging.error("Failed to fetch devServer %s info: %s", server_id, str(e))
            return None
        logging.info("Successfully fetch devServer %s info", server_id)
        return resp

    #创建DevServer超节点标签
    def create_hps_tag(self, hps_cluster_id: str, tags: List[Tag]):
        validate_server_id(hps_cluster_id)
        if not isinstance(tags, list) or not all(isinstance(tag, Tag) for tag in tags):
            raise TypeError("The parameter 'tags' must be a list of Tag objects.")
        tag_list = []
        for tag in tags:
            tag_dict = {}
            if tag.hps_key:
                tag_dict["key"] = tag.hps_key
            if tag.hps_value:
                tag_dict["value"] = tag.hps_value
            if tag_dict:
                tag_list.append(tag_dict)
        body = {
            "tags": tag_list
        }
        request_url = "/v1/" + self._session.project_id + "/dev-servers/hyperinstance/" + hps_cluster_id + "/tags/create"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_POST, request_url, body=JSONEncoder().encode(body))
        except APIGException as e:
            logging.error("Failed to create hps tag. %s", str(e))
            return None
        logging.info("Successfully created hps tag.")
        return resp

    #删除DevServer超节点标签
    def delete_hps_tag(self, hps_cluster_id: str, tags: List[Tag]):
        validate_server_id(hps_cluster_id)
        if not isinstance(tags, list) or not all(isinstance(tag, Tag) for tag in tags):
            raise TypeError("The parameter 'tags' must be a list of Tag objects.")
        tag_list = []
        for tag in tags:
            tag_dict = {}
            if tag.hps_key:
                tag_dict["key"] = tag.hps_key
            if tag.hps_value:
                tag_dict["value"] = tag.hps_value
            if tag_dict:
                tag_list.append(tag_dict)
        body = {
            "tags": tag_list
        }
        request_url = "/v1/" + self._session.project_id + "/dev-servers/hyperinstance/" + hps_cluster_id + "/tags/delete"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_POST, request_url, body=JSONEncoder().encode(body))
        except APIGException as e:
            logging.error("Failed to delete hps tag. %s", str(e))
            return None
        logging.info("Successfully deleted hps tag.")
        return resp

    #查询DevServer超节点标签
    def get_hps_tags(self, hps_cluster_id: str):
        validate_server_id(hps_cluster_id)
        request_url = "/v1/" + self._session.project_id + "/dev-servers/hyperinstance/" + hps_cluster_id + "/tags"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_GET, request_url)
        except APIGException as e:
            logging.error("Failed to get HPS %s tag: %s", hps_cluster_id, str(e))
            return None
        logging.info("Successfully get HPS %s tag", hps_cluster_id)
        return resp

    #重装DevServer服务器操作系统镜像
    def reinstall_server_image(self, server_id: str, image_body: ImageBody):
        validate_server_id(server_id)
        if image_body.image_id:
            logging.warning("image_id will be ignored in reinstall_hps_image API.")
        body={}
        if image_body.admin_pass:
            body.update({"admin_pass": image_body.admin_pass})
        if image_body.key_pair_name:
            body.update({"key_pair_name": image_body.key_pair_name})
        if image_body.user_data:
            body.update({"userdata": image_body.user_data})
        request_url = "/v1/" + self._session.project_id + "/dev-servers/" + server_id + "/reinstallos"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_POST, request_url, body=JSONEncoder().encode(body))
        except APIGException as e:
            logging.error("Failed to reinstall server image %s. %s", image_body.image_id, str(e))
            return None
        logging.info("Successfully reinstalled server image.")
        return resp

    #切换DevServer服务器操作系统镜像
    def change_server_image(self, server_id: str, image_body: ImageBody):
        validate_server_id(server_id)
        if not image_body.image_id:
            raise ValueError("image_id must be specified for changing image.")
        # 获取当前实例信息，提取已有 image_id
        try:
            current_info = self.get_server_info(server_id)
            if current_info is None:
                raise RuntimeError(f"Server info is None for ID: {server_id}")
        except APIGException as e:
            logging.error("Failed to fetch devServer %s info: %s", server_id, str(e))
            return None
        current_image = current_info.get("image", {})
        current_image_id = current_image.get("image_id")
        if current_image_id == image_body.image_id:
            logging.warning("Skipped image change: image_id is the same (%s)", current_image_id)
            return {"message": f"Skipped: image_id unchanged ({current_image_id})"}
        # 构造请求体
        body = {"image_id": image_body.image_id}
        if image_body.admin_pass:
            body.update({"admin_pass": image_body.admin_pass})
        if image_body.key_pair_name:
            body.update({"key_pair_name": image_body.key_pair_name})
        if image_body.user_data:
            body.update({"userdata": image_body.user_data})
        request_url = "/v1/" + self._session.project_id + "/dev-servers/" + server_id + "/changeos"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_POST, request_url, body=JSONEncoder().encode(body))
        except APIGException as e:
            logging.error("Failed to change server image %s. %s", image_body.image_id,str(e))
            return None
        logging.info("Successfully changed server image, the new image id is: %s.", image_body.image_id)
        return resp

    #切换DevServer超节点服务器操作系统镜像
    def change_hps_image(self, hps_cluster_id: str, image_body: ImageBody):
        validate_server_id(hps_cluster_id)
        if not image_body.image_id:
            raise ValueError("image_id must be specified for changing image.")
        # 获取当前实例信息，提取已有 image_id
        try:
            current_info = self.get_hps_info(hps_cluster_id)
            if current_info is None:
                raise RuntimeError(f"Server info is None for ID: {hps_cluster_id}")
        except APIGException as e:
            logging.error("Failed to fetch devServer %s info: %s", hps_cluster_id, str(e))
            return None
        servers = current_info.get("servers", [])
        current_image = servers[0].get("image", {})
        current_image_id = current_image.get("image_id")
        if current_image_id == image_body.image_id:
            logging.warning("Skipped image change: image_id is the same (%s)", current_image_id)
            return {"message": f"Skipped: image_id unchanged ({current_image_id})"}
        body={"image_id": image_body.image_id}
        if image_body.admin_pass:
            body.update({"admin_pass": image_body.admin_pass})
        if image_body.key_pair_name:
            body.update({"key_pair_name": image_body.key_pair_name})
        if image_body.user_data:
            body.update({"userdata": image_body.user_data})
        request_url = "/v1/" + self._session.project_id + "/dev-servers/hyperinstance/" + hps_cluster_id + "/changeos"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_POST, request_url, body=JSONEncoder().encode(body))
        except APIGException as e:
            logging.error("Failed to change hps image %s. %s", image_body.image_id, str(e))
            return None
        logging.info("Successfully changed hps image, the new image id is: %s.", image_body.image_id)
        return resp

    #查询用户所有超节点实例详情
    def get_hps_list(self, params=None):
        if not params:
            params = dict()
        request_url = "/v1/" + self._session.project_id + "/dev-servers/hyperinstance"
        return auth_by_apig(self._session, constant.HTTPS_GET, request_url, query=params)

    #查询指定超节点实例详情
    def get_hps_info(self, hps_cluster_id: str):
        validate_server_id(hps_cluster_id)
        request_url = "/v1/" + self._session.project_id + "/dev-servers/hyperinstance/" + hps_cluster_id
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_GET, request_url)
        except APIGException as e:
            logging.error("Failed to fetch devServer %s info: %s", hps_cluster_id, str(e))
            return None
        logging.info("Successfully fetch devServer %s info", hps_cluster_id)
        return resp

    #删除DevServer超节点实例
    def delete_hps(self, hps_cluster_id: str):
        validate_server_id(hps_cluster_id)
        request_url = "/v1/" + self._session.project_id + "/dev-servers/hyperinstance/" + hps_cluster_id
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_DELETE, request_url)
        except APIGException as e:
            logging.error("Failed to delete hps %s. %s", hps_cluster_id, str(e))
            return None
        logging.info("Successfully deleted hps: %s", hps_cluster_id)
        return resp

    #重启DevServer实例
    def restart(self, server_id: str):
        validate_server_id(server_id)
        request_url = "/v1/" + self._session.project_id + "/dev-servers/" + server_id + "/reboot"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_PUT, request_url)
        except APIGException as e:
            logging.error("Failed to restart devserver %s. %s", server_id, str(e))
            return None
        logging.info("Successfully restarted devserver %s.", server_id)
        return resp

    #启动DevServer超节点服务器(开机)
    def start_hps(self, hps_cluster_id: str):
        validate_server_id(hps_cluster_id)
        request_url = "/v1/" + self._session.project_id + "/dev-servers/hyperinstance/" + hps_cluster_id + "/start"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_PUT, request_url)
        except APIGException as e:
            logging.error("Failed to start hps %s. %s", hps_cluster_id, str(e))
            return None
        logging.info("Successfully started hps %s.", hps_cluster_id)
        return resp

    #停止DevServer超节点服务器（关机）
    def stop_hps(self, hps_cluster_id: str):
        validate_server_id(hps_cluster_id)
        request_url = "/v1/" + self._session.project_id + "/dev-servers/hyperinstance/" + hps_cluster_id + "/stop"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_PUT, request_url)
        except APIGException as e:
            logging.error("Failed to stop hps %s. %s", hps_cluster_id, str(e))
            return None
        logging.info("Successfully stopped hps %s.", hps_cluster_id)
        return resp

    #DevServer服务器挂载磁盘
    def attach_volume(self, server_id: str, volume: Volume):
        validate_server_id(server_id)
        body = {"volume_id": volume.volume_id}
        request_url = "/v1/" + self._session.project_id + "/dev-servers/" + server_id + "/attachvolume"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_POST, request_url, body=JSONEncoder().encode(body))
        except APIGException as e:
            logging.error("Failed to attach volume %s. %s", volume.volume_id,str(e))
            return None
        logging.info("Successfully attached volume %s on server %s.", volume.volume_id, server_id)
        return resp

    #DevServer服务器绑定的EIP
    def bind_eip(self, server_id: str, bind_ip: BindIP):
        validate_server_id(server_id)
        body = {"public_ip_id": bind_ip.public_ip_id}
        request_url = "/v1/" + self._session.project_id + "/dev-servers/" + server_id + "/publicips"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_POST, request_url, body=JSONEncoder().encode(body))
        except APIGException as e:
            logging.error("Failed to bind eip %s on server %s.", bind_ip.public_ip_id, str(e))
            return None
        logging.info("Successfully binded eip %s on server %s.", bind_ip.public_ip_id, server_id)
        return resp

    #查询DevServer服务器绑定的EIP
    def get_server_eip(self, server_id: str):
        validate_server_id(server_id)
        request_url = "/v1/" + self._session.project_id + "/dev-servers/" + server_id + "/publicips"
        try:
            resp = auth_by_apig(self._session, constant.HTTPS_GET, request_url)
        except APIGException as e:
            logging.error("Failed to fetch server %s EIP info: %s.", server_id, str(e))
            return None
        logging.info("Successfully fetched server %s EIP", server_id)
        return resp

def get_server_api_instance(session):
    return ServerApiAKSKImpl(session)