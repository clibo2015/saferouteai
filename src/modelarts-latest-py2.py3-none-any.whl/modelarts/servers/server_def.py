class ChargingInfo(object):
    def __init__(self, charging_mode: str, period_num: int, period_type: str,
                 is_auto_pay: bool = False, is_auto_renew: bool = False):
        self.charging_mode = charging_mode
        self.is_auto_pay = is_auto_pay
        self.is_auto_renew = is_auto_renew
        self.period_num = period_num
        self.period_type = period_type


class Network(object):
    def __init__(self, security_group_id: str, subnet_id: str, vpc_id: str,
                 ipv6_enable: bool = False, roce_id: str = None):
        self.ipv6_enable = ipv6_enable
        self.roce_id = roce_id
        self.security_group_id = security_group_id
        self.subnet_id = subnet_id
        self.vpc_id = vpc_id


class RootVolume(object):
    def __init__(self, root_type: str = None, size: int = None):
        self.root_type = root_type
        self.size = size


class DataVolume(object):
    def __init__(self, data_type: str, size: int, count: int):
        self.data_type = data_type
        self.size = size
        self.count = count


class Server(object):
    def __init__(self, name: str, flavor: str, network: Network, image_id: str = None, image_url: str = None,
                 arch: str = None, admin_pass: str = None, availability_zone: str = None,
                 charging_info: ChargingInfo = None, key_pair_name: str = None, root_volume: RootVolume = None,
                 data_volume: DataVolume = None, server_type: str = None, userdata: str = None,
                 hps_cluster_id: str = None, enterprise_project_id: str = None, count: int = None):
        self.name = name
        if admin_pass and key_pair_name:
            raise ValueError("Only one of 'admin_pass' or 'key_pair_name' should be specified.")
        self.admin_pass = admin_pass
        self.flavor = flavor
        if not image_id and not image_url:
            raise ValueError("The parameter 'image_id' and 'image_url' cannot be null at the same time.")
        self.image_id = image_id
        self.image_url = image_url
        self.arch = arch
        self.availability_zone = availability_zone
        self.charging_info = charging_info
        self.key_pair_name = key_pair_name
        self.network = network
        self.root_volume = root_volume
        self.data_volume = data_volume
        self.server_type = server_type
        self.userdata = userdata
        self.hps_cluster_id = hps_cluster_id
        self.enterprise_project_id = enterprise_project_id
        self.count = count


class Tag(object):
    def __init__(self, hps_key: str = None, hps_value: str = None):
        self.hps_key = hps_key
        self.hps_value = hps_value


class ImageBody(object):
    def __init__(self, image_id: str = None, admin_pass: str = None, key_pair_name: str = None, user_data: str = None):
        self.image_id = image_id
        if admin_pass and key_pair_name:
            raise ValueError("Only one of 'admin_pass' or 'key_pair_name' should be specified.")
        self.admin_pass = admin_pass
        self.key_pair_name = key_pair_name
        self.user_data = user_data


class Volume(object):
    def __init__(self, volume_id: str):
        self.volume_id = volume_id


class BindIP(object):
    def __init__(self, public_ip_id: str):
        self.public_ip_id = public_ip_id